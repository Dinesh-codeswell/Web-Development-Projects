
import { useState, useRef, useEffect } from 'react';
import { Send, Smartphone, Bot, User, MessageSquare, Info, HelpCircle, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ThemeToggle } from '@/components/theme-toggle';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

const Index = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hi! I'm your iPhone Insight Buddy. I can help you with anything related to iPhones - from troubleshooting to features, comparisons, and tips. What would you like to know?",
      role: 'assistant',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollElement = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const callPerplexityAPI = async (message: string): Promise<string> => {
    try {
      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer 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`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'llama-3.1-sonar-small-128k-online',
          messages: [
            {
              role: 'system',
              content: 'You are an iPhone expert assistant. Provide helpful, accurate, and detailed information about iPhones, iOS, Apple products, troubleshooting, features, and related topics. Be concise but thorough in your responses.'
            },
            {
              role: 'user',
              content: message
            }
          ],
          temperature: 0.2,
          top_p: 0.9,
          max_tokens: 1000,
          return_images: false,
          return_related_questions: false,
          frequency_penalty: 1,
          presence_penalty: 0
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.choices[0]?.message?.content || 'Sorry, I could not process your request.';
    } catch (error) {
      console.error('Perplexity API Error:', error);
      throw new Error('Failed to get response from AI service');
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input.trim(),
      role: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await callPerplexityAPI(userMessage.content);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response,
        role: 'assistant',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get response. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const iPhoneTips = [
    { 
      title: "Battery Optimization", 
      content: "Enable Optimized Battery Charging in Settings > Battery > Battery Health to extend battery lifespan. Also, keep background app refresh limited to essential apps." 
    },
    { 
      title: "Back Tap Shortcuts", 
      content: "Configure Double or Triple Back Tap in Settings > Accessibility > Touch > Back Tap to trigger shortcuts like taking screenshots or opening the camera."
    },
    { 
      title: "Camera Quick Access", 
      content: "From the lock screen, simply swipe left to quickly access the camera. Use volume buttons as shutter controls for better stability."
    },
    { 
      title: "Face ID Enhancement", 
      content: "Set up an alternate appearance in Face ID settings for better recognition with different looks. Also enable 'Require Attention' for added security."
    }
  ];

  const quickActions = [
    { title: "Troubleshoot Battery", query: "How can I fix battery drain on my iPhone?" },
    { title: "Face ID Not Working", query: "My Face ID stopped working. How can I fix it?" },
    { title: "iPhone vs Android", query: "What are the key differences between iPhone and Android?" },
    { title: "Latest iOS Features", query: "What are the best new features in the latest iOS update?" }
  ];

  return (
    <div className="relative min-h-screen w-full">
      {/* Refined Background */}
      <div className="fixed inset-0 overflow-hidden -z-10">
        <div className="absolute top-0 w-full h-full bg-gradient-to-b from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-blue-950 transition-colors duration-500"></div>
        
        {/* Abstract Shapes - More subtle and professional */}
        <div className="absolute w-[800px] h-[800px] rounded-full bg-gradient-to-br from-blue-100/30 to-indigo-100/30 dark:from-blue-800/10 dark:to-indigo-800/10 blur-3xl -top-[400px] -left-[400px] pulse-slow"></div>
        <div className="absolute w-[600px] h-[600px] rounded-full bg-gradient-to-br from-indigo-100/20 to-purple-100/20 dark:from-indigo-800/10 dark:to-purple-800/10 blur-3xl -bottom-[300px] -right-[300px] pulse-slow" style={{animationDelay: '2s'}}></div>
        
        {/* Subtle Grid Overlay */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMtOS45NDEgMC0xOCA4LjA1OS0xOCAxOGg2YTEyIDEyIDAgMCAxIDEyLTEydjZ6IiBmaWxsPSJyZ2JhKDAsIDAsIDAsIDAuMDIpIi8+PC9nPjwvc3ZnPg==')] dark:bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMtOS45NDEgMC0xOCA4LjA1OS0xOCAxOGg2YTEyIDEyIDAgMCAxIDEyLTEydjZ6IiBmaWxsPSJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDIpIi8+PC9nPjwvc3ZnPg==')]"></div>
      </div>

      <div className="container mx-auto max-w-4xl px-4 py-8 relative">
        {/* Header with Theme Toggle */}
        <header className="text-center mb-8 animate-in">
          <div className="flex items-center justify-between mb-2">
            <div className="flex-1 flex justify-start">
              <div className="flex items-center gap-2 bg-white/50 dark:bg-gray-800/50 px-3 py-1.5 rounded-full subtle-shadow">
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                <span className="text-xs font-medium text-gray-600 dark:text-gray-300">AI Powered</span>
              </div>
            </div>
            
            <div className="flex items-center justify-center gap-3 flex-1">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 dark:from-blue-400 dark:to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20 dark:shadow-blue-500/10">
                <Smartphone className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-3xl font-bold gradient-text">
                iPhone Expert
              </h1>
            </div>
            
            <div className="flex-1 flex justify-end">
              <ThemeToggle />
            </div>
          </div>
          
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mt-2 text-sm">
            Your intelligent assistant for all things iPhone. Ask any question about features, troubleshooting, or tips.
          </p>
        </header>

        {/* Main Content Tabs */}
        <Tabs defaultValue="chat" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 max-w-xs mx-auto mb-6 bg-white/50 dark:bg-gray-800/50 subtle-shadow">
            <TabsTrigger 
              value="chat" 
              className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700"
            >
              <MessageSquare className="h-4 w-4" /> Chat
            </TabsTrigger>
            <TabsTrigger 
              value="tips" 
              className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700"
            >
              <Info className="h-4 w-4" /> Quick Tips
            </TabsTrigger>
          </TabsList>
          
          {/* Chat Tab */}
          <TabsContent value="chat" className="mt-0 space-y-4 animate-in">
            {/* Chat Container */}
            <Card className="h-[600px] flex flex-col glass-card rounded-2xl subtle-shadow border-0">
              {/* Messages Area */}
              <ScrollArea ref={scrollAreaRef} className="flex-1 p-6">
                <div className="space-y-6">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex gap-4 ${
                        message.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                      }`}
                    >
                      <Avatar className={`w-10 h-10 ${
                        message.role === 'user' 
                          ? 'bg-gradient-to-br from-blue-500 to-indigo-600 shadow-sm shadow-blue-500/20' 
                          : 'bg-gradient-to-br from-gray-500 to-gray-600 shadow-sm shadow-gray-500/20'
                      }`}>
                        <AvatarFallback className="text-white">
                          {message.role === 'user' ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                        </AvatarFallback>
                      </Avatar>
                      <div
                        className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                          message.role === 'user'
                            ? 'bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-sm shadow-blue-500/20'
                            : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 shadow-sm border border-gray-100 dark:border-gray-700'
                        }`}
                      >
                        <p className="whitespace-pre-wrap leading-relaxed text-sm">{message.content}</p>
                        <p className={`text-xs mt-2 ${
                          message.role === 'user' ? 'text-blue-100' : 'text-gray-400 dark:text-gray-500'
                        }`}>
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex gap-4">
                      <Avatar className="w-10 h-10 bg-gradient-to-br from-gray-500 to-gray-600 shadow-sm shadow-gray-500/20">
                        <AvatarFallback className="text-white">
                          <Bot className="h-5 w-5" />
                        </AvatarFallback>
                      </Avatar>
                      <div className="bg-white dark:bg-gray-800 rounded-2xl px-4 py-3 shadow-sm border border-gray-100 dark:border-gray-700">
                        <div className="flex space-x-2">
                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>

              {/* Input Area */}
              <div className="p-4 border-t border-gray-100 dark:border-gray-800 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-b-2xl">
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask anything about iPhones..."
                    className="flex-1 bg-gray-50 dark:bg-gray-900 border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
                    disabled={isLoading}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={isLoading || !input.trim()}
                    className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white rounded-xl px-5 disabled:opacity-50 transition-all duration-200 shadow-sm shadow-blue-500/20"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* Quick Action Pills */}
                <div className="mt-3 flex flex-wrap gap-2 justify-center">
                  {quickActions.map((action, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setInput(action.query);
                      }}
                      className="text-xs py-1.5 px-3 bg-gray-50 dark:bg-gray-900 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 transition-colors"
                    >
                      {action.title}
                    </button>
                  ))}
                </div>
              </div>
            </Card>
          </TabsContent>
          
          {/* Tips Tab */}
          <TabsContent value="tips" className="mt-0 animate-in">
            <Card className="h-[600px] flex flex-col glass-card rounded-2xl subtle-shadow overflow-auto border-0">
              <div className="p-6">
                <h2 className="text-2xl font-bold text-center mb-6 gradient-text">iPhone Pro Tips</h2>
                
                <div className="grid md:grid-cols-2 gap-5">
                  {iPhoneTips.map((tip, index) => (
                    <div key={index} className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow border border-gray-100 dark:border-gray-700">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                          <span className="text-blue-500 dark:text-blue-400 font-medium">{index + 1}</span>
                        </div>
                        <h3 className="font-medium text-blue-600 dark:text-blue-400">{tip.title}</h3>
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 text-sm">{tip.content}</p>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 p-5 rounded-xl border border-blue-100 dark:border-blue-800/30">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-blue-500 rounded-full text-white">
                      <Info className="h-4 w-4" />
                    </div>
                    <h3 className="font-medium text-gray-800 dark:text-gray-100">Did you know?</h3>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">
                    You can use your iPhone's camera to translate text in real-time. Just open the Camera app, point it at text in a foreign language, tap the text selection button that appears, and select "Translate" from the options.
                  </p>
                </div>
                
                <div className="mt-6 text-center">
                  <Button 
                    onClick={() => setActiveTab('chat')}
                    className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 rounded-xl px-5 py-2 text-white shadow-sm shadow-blue-500/20 transition-all duration-200"
                  >
                    <HelpCircle className="h-4 w-4 mr-2" />
                    Ask For More Tips
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Feature Grid */}
        <div className="grid md:grid-cols-3 gap-4 mt-8 animate-in" style={{ animationDelay: '0.2s' }}>
          <Card className="p-5 glass-card border-0 subtle-shadow rounded-xl hover:shadow-md transition-all">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-3">
                <Smartphone className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="font-medium text-gray-800 dark:text-gray-100 mb-1">Device Support</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400">Get help with iPhone setup, features, and troubleshooting</p>
            </div>
          </Card>
          
          <Card className="p-5 glass-card border-0 subtle-shadow rounded-xl hover:shadow-md transition-all">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center mb-3">
                <Bot className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
              </div>
              <h3 className="font-medium text-gray-800 dark:text-gray-100 mb-1">AI Assistant</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400">Intelligent answers powered by advanced AI technology</p>
            </div>
          </Card>
          
          <Card className="p-5 glass-card border-0 subtle-shadow rounded-xl hover:shadow-md transition-all">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center mb-3">
                <User className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="font-medium text-gray-800 dark:text-gray-100 mb-1">Personalized Help</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400">Tailored advice for your specific iPhone model and iOS version</p>
            </div>
          </Card>
        </div>
        
        {/* Footer */}
        <footer className="mt-8 text-center pt-4 border-t border-gray-200 dark:border-gray-800">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            © {new Date().getFullYear()} iPhone Expert Assistant • Powered by Perplexity AI
          </p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
